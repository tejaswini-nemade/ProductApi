﻿using System;
using System.Net;
using ProductApi.Services.Model;

namespace ProductApi
{
    public class GetByIdOp
    {
        public GetByIdOp()
        {
        }

        public class Request
        {
            public Guid ProductId { get; set; }
        }

        public class Response
        {
            public HttpStatusCode HttpStatus { get; set; }
            public string? ErrorMessage { get; set; }

            public Guid ProductId { get; set; }
            public string? ProductName { get; set; }
            public string? ProductCode { get; set; }
            public string? CreatedBy { get; set; }
            public DateTime CreatedDate { get; set; }
            public Guid SizeScaleId { get; set; }
            public int ChannelId { get; set; }
            public List<Article>? Articles { get; set; }
            public List<Size>? Sizes { get; set; }

        }
    }
}

