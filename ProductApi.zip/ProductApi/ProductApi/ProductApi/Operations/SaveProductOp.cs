﻿using System;
using System.Net;
using ProductApi.Models;

namespace ProductApi
{
    public class SaveProductOp
    {
        public SaveProductOp()
        {
        }

        public class Request
        {
            public Guid ProductId { get; set; }
            public string? ProductName { get; set; }
            public int ProductYear { get; set; }
            public int ChannelId { get; set; }
            public Guid SizeScaleId { get; set; }
            public List<Article>? Articles { get; set; }
        }

        public class Response 
        {
            public HttpStatusCode HttpStatus { get; set; }
            public string? ErrorMessage { get; set; }
        }
    }
}

