﻿using System;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Polly;
using ProductApi.DataAccess;
using ProductApi.Services;
using ProductApi.Services.Config;
using ProductApi.Validators;

namespace ProductApi
{
    public class Startup
    {
        public Startup()
        {
        }

        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
         
            services.AddDbContext<ProductDbContext>(x => x.UseSqlServer(Configuration.GetConnectionString("ConStr")));

            //  var ConnectionString = "Server=localhost;Database=ProductsDb;User Id=sa;Password=Password%123;Integrated Security=False;";

            var ConnectionString = Configuration.GetConnectionString("ProductDatabase");
            services.AddTransient<IProductService, ProductService>();
            //services.AddTransient<IColorService, ColorService>();
            //services.AddTransient<ISizeScaleService, SizeScaleService>();

            //Entity Framework  
            services.AddDbContext<ProductApi.DataAccess.ProductDbContext>(options => options.UseSqlServer(ConnectionString));
            services.AddHttpContextAccessor();

            services.AddScoped<IValidator<SaveProductOp.Request>, IsSaveProductValidator>();

            services.AddAuthentication();


            services
                           .AddOptions<ColorApiConfig>()
                           .Configure<IConfiguration>((colorApiSettings, configuration) =>
                           {
                               configuration
                                   .GetSection("ColorApiAppsetting")
                                   .Bind(colorApiSettings);
                           })
                           ;

            services.AddHttpClient<IColorService, ColorService>((sp, _) =>
            {
                _.BaseAddress = new Uri(sp.GetService<IOptions<ColorApiConfig>>().Value.ColorApiURL);
                _.DefaultRequestHeaders.Add("Accept", "application/json");
            })
                .SetHandlerLifetime(TimeSpan.FromMinutes(5))
                .AddPolicyHandler((sp, req) =>
                {
                    return Polly.Extensions.Http.HttpPolicyExtensions
                        .HandleTransientHttpError()
                        .WaitAndRetryAsync(3, retryCount => TimeSpan.FromSeconds(1), (result, retryIn, retryCount, context) =>
                        {
                            var logger = sp.GetService<ILogger<ColorService>>();

                            if (result.Exception != null)
                            {
                                logger?.LogError(result.Exception, $"An exception occurred. Retry {retryCount} in {retryIn.TotalSeconds} seconds");
                            }
                            else
                            {
                                logger?.LogError($"A non success code '{result.Result.StatusCode}' was received. Retry {retryCount} in {retryIn.TotalSeconds} seconds.");
                            }
                        });
                });

            services
                           .AddOptions<SizeScaleApiConfig>()
                           .Configure<IConfiguration>((colorApiSettings, configuration) =>
                           {
                               configuration
                                   .GetSection("SizeScaleApiAppsetting")
                                   .Bind(colorApiSettings);
                           })
                           ;

            services.AddHttpClient<ISizeScaleService, SizeScaleService>((sp, _) =>
            {
                _.BaseAddress = new Uri(sp.GetService<IOptions<SizeScaleApiConfig>>().Value.SizeScaleApiUrl);
                _.DefaultRequestHeaders.Add("Accept", "application/json");
            })
                .SetHandlerLifetime(TimeSpan.FromMinutes(5))
                .AddPolicyHandler((sp, req) =>
                {
                    return Polly.Extensions.Http.HttpPolicyExtensions
                        .HandleTransientHttpError()
                        .WaitAndRetryAsync(3, retryCount => TimeSpan.FromSeconds(1), (result, retryIn, retryCount, context) =>
                        {
                            var logger = sp.GetService<ILogger<SizeScaleService>>();

                            if (result.Exception != null)
                            {
                                logger?.LogError(result.Exception, $"An exception occurred. Retry {retryCount} in {retryIn.TotalSeconds} seconds");
                            }
                            else
                            {
                                logger?.LogError($"A non success code '{result.Result.StatusCode}' was received. Retry {retryCount} in {retryIn.TotalSeconds} seconds.");
                            }
                        });
                });


        }


       
    }
}



