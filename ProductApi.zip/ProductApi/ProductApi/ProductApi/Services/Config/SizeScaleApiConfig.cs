﻿using System;
namespace ProductApi.Services.Config
{
    public class SizeScaleApiConfig
    {
        public SizeScaleApiConfig()
        {
        }

        public int SizeScaleApiClientId { get; set; }
        public string SizeScaleApiUrl { get; set; }
        public List<string> Scope { get; set; }
    }
}

