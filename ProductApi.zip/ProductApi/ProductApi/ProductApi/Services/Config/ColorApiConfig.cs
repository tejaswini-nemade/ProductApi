﻿using System;
namespace ProductApi.Services.Config
{
    public class ColorApiConfig
    {
        public ColorApiConfig()
        {
        }

        public int ColorApiClientId { get; set; }
        public string ColorApiURL { get; set; }
        public List<string> Scope { get; set; }
    }
}