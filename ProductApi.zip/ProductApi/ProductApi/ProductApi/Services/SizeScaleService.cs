﻿using System;
using System.Net;
using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Web;
using Newtonsoft.Json;
using ProductApi.Services.Config;
using ProductApi.Services.Extensions;

namespace ProductApi.Services
{
    public class SizeScaleService :ISizeScaleService
    {
        private readonly HttpClient _httpClient;
        private readonly ITokenAcquisition _tokenAcquisition;
        private readonly ILogger<SizeScaleService> _logger;
        private readonly SizeScaleApiConfig _sizeScaleApiConfig;

        public SizeScaleService()
        {
        }

        public SizeScaleService(HttpClient httpClient, IOptions<SizeScaleApiConfig> sizeScaleApiConfig, ILogger<SizeScaleService> logger, ITokenAcquisition tokenAcquisition)
        {
            _httpClient = httpClient;
            _tokenAcquisition = tokenAcquisition;
            _logger = logger;
            _sizeScaleApiConfig = sizeScaleApiConfig.Value ?? throw new ArgumentNullException($"{nameof(sizeScaleApiConfig)}");
        }

        public async Task<SizeDetail> GetSizes(Guid SizescaleId)
        {
            HttpResponseMessage response;
            string content;

            try
            {
                string accessToken = await _tokenAcquisition.GetAccessTokenForUserAsync(_sizeScaleApiConfig.Scope);

                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);


                 response = await _httpClient.GetAsync(string.Format(_sizeScaleApiConfig.SizeScaleApiUrl, SizescaleId));

                 content = await response.Content.ReadAsStringAsync();

                _logger.LogInformation($" Sizescale Service response {nameof(GetSizes)} - { response}");
            }
             
            catch (Exception ex)
            {
                _logger.LogError($"Error in {nameof(SizeDetail)} - {ex.Message}", ex);
                throw;
            }

            await response.CustomEnsureSuccessStatusCode(_logger);

            return JsonConvert.DeserializeObject<SizeDetail>(content);
        }
    }

    public interface ISizeScaleService
    {
      
        public Task<SizeDetail> GetSizes(Guid SizescaleId);

    }

    public class SizeDetail
    {
        public Guid SizeId { get; set; }
        public string? SizeName { get; set; }
    }
}

