﻿using System;
using Newtonsoft.Json;

namespace ProductApi.Services.Extensions
{
    public static class HttpResponseExtensions
    {
        public static async Task<T> Deserialize<T>(this HttpResponseMessage response)
        {
            var content = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(content);
        }

        public static async Task CustomEnsureSuccessStatusCode(this HttpResponseMessage message, ILogger logger)
        {
            if (message.IsSuccessStatusCode)
                return;

            var requestMessage = message.RequestMessage.Content != null ? await message.RequestMessage.Content.ReadAsStringAsync() : "";

            var responseMessage = await message.Content.ReadAsStringAsync();

            var contentMessage = string.IsNullOrWhiteSpace(responseMessage)
                ? string.Empty
                : $"Response Content: {responseMessage}";

            logger.LogError($"Invalid response for url: {message.RequestMessage.RequestUri}, Request: {requestMessage}. Http response code: {message.StatusCode} ({message.ReasonPhrase}). {contentMessage}");

            throw new HttpRequestException($"Response status code does not indicate success: {(int)message.StatusCode} ({message.ReasonPhrase}).");
        }
    }
}

