﻿using System;
using System.Net;
using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Web;
using Newtonsoft.Json;
using ProductApi.Services.Config;
using ProductApi.Services.Extensions;

namespace ProductApi.Services
{
    public class ColorService : IColorService
    {

        private readonly HttpClient _httpClient;
        private readonly ITokenAcquisition _tokenAcquisition;
        private readonly ILogger<ColorService> _logger;
        private readonly ColorApiConfig _colorApiConfig;

        public ColorService()
        {
        }

        public ColorService(HttpClient httpClient,  IOptions<ColorApiConfig> colorApiConfig, ILogger<ColorService> logger, ITokenAcquisition  tokenAcquisition)
        {
            _httpClient = httpClient;
            _tokenAcquisition = tokenAcquisition;
            _logger = logger;
            _colorApiConfig = colorApiConfig.Value ?? throw new ArgumentNullException($"{nameof(colorApiConfig)}");
        }

        public async Task<List<ColorDetail>> GetAllColors()
        {
            HttpResponseMessage response;
            string content;

            try
            {

                string accessToken = await _tokenAcquisition.GetAccessTokenForUserAsync(_colorApiConfig.Scope);

               _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                response = await _httpClient.GetAsync(string.Format(_colorApiConfig.ColorApiURL, "/GetColors"));

                content = await response.Content.ReadAsStringAsync();

                _logger.LogInformation($" Color Service response {nameof(GetAllColors)} - { response}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in {nameof(GetAllColors)} - {ex.Message}", ex);
                throw;
            }

            await response.CustomEnsureSuccessStatusCode(_logger);

            return JsonConvert.DeserializeObject<List<ColorDetail>>(content);

        }


        public async Task<ColorDetail> GetClour(Guid ColorId)
        {

            HttpResponseMessage response;
            string content;

            try
            {

                string accessToken = await _tokenAcquisition.GetAccessTokenForUserAsync(_colorApiConfig.Scope);

                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);


                 response = await _httpClient.GetAsync(string.Format(_colorApiConfig.ColorApiURL, ColorId));

                 content = await response.Content.ReadAsStringAsync();

                _logger.LogInformation($" Color Service response {nameof(GetClour)} - { response}");

            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in {nameof(GetClour)} - {ex.Message}", ex);
                throw;
            }

            await response.CustomEnsureSuccessStatusCode(_logger);

            return JsonConvert.DeserializeObject<ColorDetail>(content);
            
        }
    }

    public interface IColorService
    {
        public Task<List<ColorDetail>> GetAllColors();
        public Task<ColorDetail> GetClour(Guid ColorId);

    }

    public class ColorDetail
    {
        public Guid ColorId { get; set; }
        public string? ColorCode { get; set; }
        public string? ColorName { get; set; }
    }
}

