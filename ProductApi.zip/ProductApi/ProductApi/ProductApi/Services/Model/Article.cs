﻿using System;
namespace ProductApi.Services.Model
{
    public class Article
    {
        public Article()
        {
        }

        public Guid ArticleId { get; set; }
        public string ArticleName  { get; set; }
        public Guid ColorId { get; set; }
        public string ColorCode { get; set; }
        public string ColorName { get; set; }
       
    }
}

