﻿using System;
namespace ProductApi.Services.Model
{
    public class Size
    {
        public Size()
        {
        }
        public Guid SizeId { get; set; }
        public string SizeNsame { get; set; }
    }
}

