﻿using System;
using ProductApi.DataAccess;
using ProductApi.Enum;
using ProductApi.Models;
using ProductApi.Services;
using ResponseModels = ProductApi.Services.Model;

namespace ProductApi
{
    public interface IProductService
    {
        public Task<SaveProductOp.Response> SaveProduct(SaveProductOp.Request request);
        public Task<GetByIdOp.Response> RetrieveProductByProductId(GetByIdOp.Request request);
    }


    public class ProductService : IProductService
    {
        private readonly ProductDbContext _dbContext;
        private readonly ColorService _colorService ;
        private readonly SizeScaleService _sizeScaleService = new SizeScaleService();
        

        public ProductService(ProductDbContext dbContext)
        {
            _dbContext = dbContext;
            _colorService = new ColorService();
            _sizeScaleService = new SizeScaleService();
        }

        public async Task<SaveProductOp.Response> SaveProduct(SaveProductOp.Request request)
        {

            if (request.ChannelId == 1)
            {
                var latestProduct = _dbContext.Products.Where(x => x.ChannelId == (int)Channel.Store).FirstOrDefault();
                
                var latestProductCode = latestProduct != null ? (Convert.ToInt64(latestProduct.ProductCode) + 1 ).ToString(): (String.Format(request.ProductYear.ToString(), "001")) ;

                var newProduct =  BuildEntity(latestProductCode, request);

                await _dbContext.AddAsync(newProduct);

                _dbContext.SaveChanges();

            }
            else if (request.ChannelId == 2)
            {
                Random random = new Random();

                const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

                var productCode = new string(Enumerable.Repeat(chars, 6)
                  .Select(s => s[random.Next(s.Length)]).ToArray());

                var newProduct = BuildEntity(productCode, request);

                await _dbContext.AddAsync(newProduct);
                _dbContext.SaveChanges();

            }
            else if (request.ChannelId == 3)
            {
                var latestProduct = _dbContext.Products.Where(x => x.ChannelId == (int)Channel.All).FirstOrDefault();
                var productCode = latestProduct != null ? (Convert.ToInt64(latestProduct.ProductCode) + 1).ToString() : "10000000";

                var newProduct = BuildEntity(productCode, request);

                await _dbContext.AddAsync(newProduct);

                _dbContext.SaveChanges();
            }

            return new SaveProductOp.Response()
            {
                HttpStatus = System.Net.HttpStatusCode.OK
            };
        }

        public async Task<GetByIdOp.Response> RetrieveProductByProductId(GetByIdOp.Request request)
        {
            var product = _dbContext.Products.Where(x => x.ProductId == request.ProductId).FirstOrDefault();
      

            if (product != null)
            {
                var productColours = await _colorService.GetClour(product.Article.FirstOrDefault().ColorId) ;
                var productSizes = await _sizeScaleService.GetSizes(product.SizeScaleId);


                return new GetByIdOp.Response()
                {
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    ProductCode = product.ProductCode,
                    SizeScaleId = product.SizeScaleId,
                    CreatedDate = product.CreatedDate,
                    CreatedBy = product.CreatedBy,
                    ChannelId = product.ChannelId,
                    Articles = new List<ResponseModels.Article>() {
                        new ResponseModels.Article()
                        {
                            ArticleId =             product.Article.FirstOrDefault().ArticleId,
                            ColorId = productColours.ColorId,
                            ColorCode = !string.IsNullOrEmpty( productColours.ColorCode) ? productColours.ColorCode: String.Empty,
                            ColorName = !string.IsNullOrEmpty( productColours.ColorName) ? productColours.ColorName: String.Empty
                        }
                    },
                    Sizes = new List<ResponseModels.Size>() {
                        new ResponseModels.Size(){
                            SizeId = productSizes.SizeId,
                            SizeNsame = !string.IsNullOrEmpty(productSizes.SizeName) ? productSizes.SizeName : String.Empty
                        }
                    },
                    HttpStatus = System.Net.HttpStatusCode.OK
                 
                };
            }
            else
            {
                return new GetByIdOp.Response() { HttpStatus = System.Net.HttpStatusCode.NotFound , ErrorMessage = "Product Id not found"};
            }
        }

        private ProductDto BuildEntity(string productCode, SaveProductOp.Request request)
        {
            return new ProductDto()
            {

                ProductId = request.ProductId,
                ProductCode = productCode,
                ProductName = request.ProductName,
                ChannelId = request.ChannelId,
                ProductYear = request.ProductYear,
                SizeScaleId = request.SizeScaleId,
                CreatedBy = "Tejaswini",
                CreatedDate = DateTime.UtcNow,
                ModifiedBy = "Tejaswini"
            };      
            
        }


    }
    
}

