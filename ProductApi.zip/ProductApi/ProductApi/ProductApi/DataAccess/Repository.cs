﻿using System;
namespace ProductApi.DataAccess
{
    public class Repository
    {
        public Repository()
        {
        }
    }
}

