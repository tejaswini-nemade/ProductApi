﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ProductApi.DataAccess
{
    public class ProductDto
    {
        public ProductDto()
        {
        }

        [Key]
        public Guid ProductId { get; set; }
        public string? ProductName { get; set; }
        public string? ProductCode { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? ModifiedBy { get; set; }
        public Guid SizeScaleId { get; set; }
        public int ChannelId { get; set; }
        public int ProductYear { get; set; }
        public ICollection<ArticleDto> Article { get; set; }

    }
}

