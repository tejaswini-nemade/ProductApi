﻿using System;
using Microsoft.EntityFrameworkCore;
using ProductApi.Models;

namespace ProductApi.DataAccess
{
    public class ProductDbContext : DbContext
    {
        

        public ProductDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<ProductDto> Products { get; set; }
        public DbSet<Article> Articles { get; set; }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured)
            {

               // optionsBuilder.UseSqlServer(@"Server=localhost;Database=ProductsDb;User Id=sa;Password=Password%123;Integrated Security=False;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        { 

            modelBuilder.Entity<ArticleDto>()
           .HasOne<ProductDto>(s => s.Product)
           .WithMany(g => g.Article)
           .HasForeignKey(s => s.ProductId);


        }
    }

}

