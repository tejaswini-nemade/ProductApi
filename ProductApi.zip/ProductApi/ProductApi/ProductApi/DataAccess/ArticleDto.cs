﻿using System;
namespace ProductApi.DataAccess
{
    public class ArticleDto
    {
        
        public int Id { get; set; }
        public Guid ArticleId { get; set; }
        public Guid ColorId { get; set; }
        public Guid ProductId { get; set; }
        public ProductDto Product { get; set; }
    }
}

