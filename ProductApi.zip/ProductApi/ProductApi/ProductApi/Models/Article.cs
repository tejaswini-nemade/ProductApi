﻿using System;
namespace ProductApi.Models
{
    public class Article
    {
        public Article()
        {
        }
        public Guid ArticleId { get; set; }
        public Guid ColorId { get; set; }
    }
}

