﻿using System;
using AutoMapper;

namespace ProductApi
{
    public class AutoMapperProfile : Profile 
    {
        public AutoMapperProfile() 
        {
            CreateMap<SaveProductOp.Request, Models.Product>()
              .ForMember(d => d.Article, _ => _.MapFrom(s => s.Articles))
              .ReverseMap();

        }
    }
}

