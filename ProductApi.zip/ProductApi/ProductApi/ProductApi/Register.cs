﻿using System;
namespace ProductApi
{
    public static class Register
    {
        public static IServiceCollection AddQuoteServices(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IProductService, ProductService>();
            return serviceCollection;
        }

    }
}

