﻿using System;
using FluentValidation;

namespace ProductApi.Validators
{
    public class IsSaveProductValidator : AbstractValidator<SaveProductOp.Request>
    {
        public IsSaveProductValidator()
        {
            
            RuleFor(x => x.ProductName).NotNull().MaximumLength(100);
            RuleFor(x => x.ChannelId).NotNull().InclusiveBetween(1, 3);
            
        }
    }
}

