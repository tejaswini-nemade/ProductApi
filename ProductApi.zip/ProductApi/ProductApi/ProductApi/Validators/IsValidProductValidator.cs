﻿using System;
using FluentValidation;
using ProductApi.Models;

namespace ProductApi.Validators
{
    public class IsValidProductValidator : AbstractValidator<Product>
    {
        public IsValidProductValidator()
        {
         
            RuleSet("ProductName", () =>
            {
                RuleFor(x => x.ProductName).NotNull().MaximumLength(100).WithMessage("Product name could not be null and should have length less than 100 ")
                .WithErrorCode(System.Net.HttpStatusCode.NotAcceptable.ToString());
            });

            RuleFor(x => x.ChannelId).NotNull().InclusiveBetween(1, 3);

            RuleForEach(d => d.Article)
                .NotNull()
                .NotEmpty()
                .SetValidator( new ArticleValidator());
                

            RuleFor(d => d.SizeScaleId)
               .NotNull()
               .NotEmpty()
               .SetValidator(new GuidValidator());

        }
    }

    public class GuidValidator : AbstractValidator<Guid>
    {
        public GuidValidator()
        {
            RuleFor(x => x).NotEmpty();
        }
    }

    public class ArticleValidator : AbstractValidator<Article>
    {
        public ArticleValidator()
        {
            RuleFor(x => x.ArticleId).NotEmpty();
        }
    }
}
