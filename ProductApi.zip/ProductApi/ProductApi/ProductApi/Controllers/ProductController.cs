﻿using System;
using System.Security.Claims;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web.Resource;
using ProductApi.DataAccess;
using ProductApi.Models;
using ProductApi.Validators;

namespace ProductApi.Controllers
{
    [ApiController]
    [RequiredScope(RequiredScopesConfigurationKey = "AzureAd:Scopes")]
    [Authorize]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly ProductDbContext _dbContext;
        private readonly IProductService _productService;
        private readonly IValidator<SaveProductOp.Request> _validator;
        private readonly ILogger<ProductController> _logger;


        public ProductController(ProductDbContext dbContext, IProductService productService, IValidator<SaveProductOp.Request> validator, ILogger<ProductController> logger)
        {

            _dbContext = dbContext;
            _productService = productService;
            _validator = validator;
            _logger = logger;

        }

        [HttpPut]
        public async Task<IActionResult> SaveProduct([FromBody]SaveProductOp.Request request)
        {
            _logger.LogInformation($" Save product request {nameof(SaveProduct)} - { request}");

            var validation = _validator.Validate(request);

            if (!validation.IsValid)
            {
                return new BadRequestObjectResult(validation.Errors);
            }

            var saveProductResponse =  await _productService.SaveProduct(request);

            _logger.LogInformation($" Save product response {nameof(SaveProduct)} - { saveProductResponse}");

            return new ObjectResult(saveProductResponse) { StatusCode = StatusCodes.Status201Created };

        }

        [HttpGet]
        public async Task<IActionResult> RetrieveProductByProductId([FromBody] GetByIdOp.Request request)
        {

            _logger.LogInformation($" Get product request {nameof(RetrieveProductByProductId)} - { request}");

            var productResponse = await _productService.RetrieveProductByProductId(request);

            _logger.LogInformation($" Get product response {nameof(RetrieveProductByProductId)} - { productResponse}");

            if (!string.IsNullOrEmpty(productResponse.ErrorMessage))
            {
                if (productResponse.HttpStatus.Equals(404))
                {
                    return new BadRequestObjectResult(productResponse);
                }
                  
            }
            return new OkObjectResult(productResponse);
        }
    }
}

