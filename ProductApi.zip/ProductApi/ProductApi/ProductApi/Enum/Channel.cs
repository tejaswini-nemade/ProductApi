﻿using System;
namespace ProductApi.Enum
{
    public enum Channel
    {
        Store = 1,
        Online = 2,
        All = 3
    }
}

